# reinforcement

Commands that can be used for running :-

(Use python2 for python2 environment ... otherwise python should be fine)

python pacman.py -p PacmanQAgent -x 2000 -n 4000 -l smallGrid -q -f --fixRandomSeed

##### Note that at line 611 of game.py, a user can modify the agentIndex = self.startingIndex into agentIndex = 1 to test the ghost level.
